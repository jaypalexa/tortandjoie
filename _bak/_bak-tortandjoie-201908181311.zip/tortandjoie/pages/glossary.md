---
layout: default
title: Glossary
---
<div>
  <h2>Glossary</h2>
  <h3>Countin’ Day</h3>
  <p>Every Friday is Countin’ Day.  That is when the contents of The Pouch are tallied.</p>
  <h3>Fauxrage</h3>
  <p>Faux — or fake — fireage.  Fauxrage is stuff that looks like money.  You end up bending down all excited to pick up your newfound fireage, only to discover that it is a gum spot or a bottle cap liner or a metal slug or some embedded property boundary dot.  Fauxrage is not cool.</p>
  <h3>Fireage</h3>
  <p>Cash money found in public places and donated to Tort and Joie’s charity fund.</p>
  <h3>Fire, Fire It, Fire It Up, Oh Fire</h3>
  <p>The Torts demanding that you (a) pick up Fireage, (b) put the Fireage in Flap, (c) transfer the Fireage from Flap to The Pouch, or (d) count the Fireage on Countin’ Day.</p>
  <h3>Flap</h3>
  <p>The original Flap was the little Parisian turtle change purse that Mommy carried on her purse.  Flap held recently-found Fireage (and his friend, Shrap).  Also, apparently, Flap was a party reptile.  Woooooo!  One day, Flap disappeared.  He has been replaced by Flap Deux.  Still looking for a Shrap Deux.</p>
  <h3>Jackie, Jackie Asserson</h3>
  <p>Refers to “jackass”…short for human being.</p>
  <h3>Kee!, KeeKee!, KeeKeeKee!, And a-kee!</h3>
  <p>The Torts laughing.</p>
  <h3>Peeps</h3>
  <p>People, usually pet or stuffed turtle owners.  Mommy and Daddy are Tort and Joie’s peeps.  The homeless-looking German guy at the Tenerife airport is the one-eyed kitten’s peep.</p>
  <h3>The Pouch</h3>
  <p>The little zippered “pocket on a string” that holds Fireage.  There are two pockets:  the big pocket holds the coins, the little pocket holds the notes.</p>
  <h3>The Torts</h3>
  <p>Tort and Joie.</p>
</div>
